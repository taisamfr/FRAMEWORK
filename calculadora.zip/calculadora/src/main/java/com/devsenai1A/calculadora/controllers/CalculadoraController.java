package com.devsenai1A.calculadora.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CalculadoraController {

	@GetMapping("/somar")
	public double somar(@RequestParam double a, @RequestParam double b) {
		return a + b;
	}
}
